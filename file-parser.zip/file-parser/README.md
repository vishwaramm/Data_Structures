# File Parser and Analyzer

This project was built to parse comma, pipe, and space delimited files that
have specific columns and indices based on certain instructions given by
def method. The project can sort the data by it's different columns.

Instructions on How to Run:
1. Download the latest version of python (3.7.1)
2. To run project cd to project folder "file-parser" and run "python -m components.main"
3. To run unit tests cd to project folder "file-parser" and run "python -m unittest"

----

This is the README file for the project.
